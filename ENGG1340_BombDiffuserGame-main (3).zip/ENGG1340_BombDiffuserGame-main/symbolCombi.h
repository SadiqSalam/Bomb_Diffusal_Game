#ifndef SYMBOLCOMBI_H
#define SYMBOLCOMBI_H

#include <chrono>

using namespace std;

int symbol(chrono::steady_clock::time_point& end_time);

#endif
